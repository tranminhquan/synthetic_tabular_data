# Travel Study

This data was collected as part of a travel study conducted by my Advanced Statistics students.

The variables are described below,

- **DomInt:** "Are you an international or domestic student?"
- **DayBoarding:** "Are you a day or boarding student?"
- **Countries:** "How many countries have you been to?"
- **Languages:** "How many languages do you speak?"
- **DualCitizenship:** "Do you have dual citizenship?" 
