# PersonalityStudy
This data was collected as part of a personality study conducted by my Advanced Statistics students. 

The variables are described below,

- **Extroverted:** "How extroverted do you think you are?" (5-point scale)
- **Introverted:** "How introverted do you think you are?" (5-point scale)
- **DomInt:** "Are you an international or domestic student?"
- **DayBoarding:** "Are you a day or boarding student?"
- **Sex:** "Are you a male or female?"
- **Zodiac:** " What is your zodiac sign?"
